def wear():
    # Function to determine what to wear based on weather input
    
    weather = input("Please enter the weather of the day to get what to wear (sunny, cloudy, rainy or windy):\n ")
    print("Your weather today is ", weather)
    
    # Check weather conditions and suggest appropriate clothing
    
    if weather == "sunny":
        print("You should wear light clothes.\n")
    elif weather == "cloudy":
        print("Wear heavy clothes as it's going to be a bit cold outside.\n")
    elif weather == "rainy":
        print("Go with a jacket, an umbrella or most definitely travel by car.\n")
    elif weather == "windy":
        print("Stay indoors if possible, wear heavy clothes to protect you from the strong winds outside.\n")
    else:
        print("We don't have that weather in Uganda.\n")
    
    check_again = input("Do you want to check the weather again? (y/n)\n").lower()
    
    # Loop to check weather multiple times if desired by the user
    
    while check_again == 'y':
        
        weather = input("Please enter the weather of the day to get what to wear (sunny, cloudy, rainy or windy):\n ")
        print("Your weather today is ", weather)
        
        # Check weather conditions and suggest appropriate clothing
        
        if weather == "sunny":
            print("You should wear light clothes.\n")
        elif weather == "cloudy":
            print("Wear heavy clothes as it's going to be a bit cold outside.\n")
        elif weather == "rainy":
            print("Go with a jacket, an umbrella or most definitely travel by car.\n")
        elif weather == "windy":
            print("Stay indoors if possible, wear heavy clothes to protect you from the strong winds outside.\n")
        else:
            print("We don't have that weather in Uganda.\n")
        
        check_again = input("Do you want to check the weather again? (y/n)\n").lower()

    print("Thank you for using the weather forecast app!\n")

# Call the function to start the program
wear()
