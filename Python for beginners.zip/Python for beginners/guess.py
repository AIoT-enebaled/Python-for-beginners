import random

# Initialize variables
attempts = 0
max_attempts = 5
range_min = 1
range_max = 100

# Generate a random number
number = random.randint(range_min, range_max)

# Display game instructions
print(f"I'm thinking of a number between {range_min} and {range_max}.")
print(f"You have {max_attempts} attempts to guess the number.")

# Start the game loop
while attempts < max_attempts:
    # Get user's guess
    guess = int(input("Enter your guess: "))
    attempts += 1

    # Check if the guess is within the valid range
    if guess < range_min or guess > range_max:
        print(f"Your guess should be between {range_min} and {range_max}.")
        continue

    # Compare the guess with the random number
    if guess > number:
        print("Too high.")
    elif guess < number:
        print("Too low.")
    else:
        print(f"Congratulations! You guessed the number in {attempts} attempts.")
        break

    # Check if the maximum number of attempts is reached
    if attempts == max_attempts:
        print(f"Sorry, you ran out of attempts. The number was {number}.")

# End of the game
