def arithmetic_operation():
    # Display the available operations
    print("Select the operation you would like to perform")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    
    # Get the operation choice from the user
    operation = int(input())

    if operation == 1:
        # Addition
        num1 = int(input("Enter the first number: "))
        num2 = int(input("Enter the second number: "))
        print("The sum of the two numbers is: " + str(num1 + num2))
        
    elif operation == 2:
        # Subtraction
        num1 = int(input("Enter the first number: "))
        num2 = int(input("Enter the second number: "))
        print("The difference of the two numbers is: " + str(num1 - num2))
        
    elif operation == 3:
        # Multiplication
        num1 = int(input("Enter the first number: "))
        num2 = int(input("Enter the second number: "))
        print("The product of the two numbers is: " + str(num1 * num2))
        
    elif operation == 4:
        # Division
        num1 = int(input("Enter the first number: "))
        num2 = int(input("Enter the second number: "))
        print("The division of the two numbers is: " + str(num1 / num2))
        
    else:
        # Invalid operation choice
        print("Invalid input")

# Call the function to start the arithmetic operation
arithmetic_operation()
